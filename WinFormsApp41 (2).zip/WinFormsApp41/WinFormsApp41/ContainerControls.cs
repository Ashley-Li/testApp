namespace WinFormsApp41
{
    public partial class ContainerControls : Form
    {
        public ContainerControls()
        {
            InitializeComponent();
        }
    }
}